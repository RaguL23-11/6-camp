const Role = require('../models/role'); // Import your Role model
const mongoose = require('mongoose');

// Create a new role
exports.createRole = async (req, res) => {
    try {
        const { role } = req.body;

        // Check if the role is provided
        if (!role) {
            return res.status(400).json({ message: 'Role is required' });
        }

        // Check if the role already exists
        const existingRole = await Role.findOne({ role });
        if (existingRole) {
            return res.status(400).json({ message: 'Role already exists' });
        }

        // Create a new role
        const newRole = new Role({ role });

        // Save the new role to the database
        await newRole.save();

        res.status(201).json({
            message: 'Role created successfully',
            role: newRole,
        });
    } catch (err) {
        console.error('Error creating role:', err);  // Log the actual error
        if (err.name === 'ValidationError') {
            return res.status(400).json({
                message: 'Validation failed',
                errors: err.errors,
            });
        }
        res.status(500).json({ message: 'Creating role failed', error: err.message });
    }
};


// Get all roles
exports.getRoles = async (req, res) => {
    try {
        const roles = await Role.find();
        res.status(200).json({
            message: 'Roles fetched successfully',
            roles,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
};

// Get a single role by its ID
exports.getRoleById = async (req, res) => {
    try {
        const { roleId } = req.params;
        const role = await Role.findById(roleId);

        if (!role) {
            return res.status(404).json({ message: 'Role not found' });
        }

        res.status(200).json({
            message: 'Role fetched successfully',
            role,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
};

// Update a role by its ID
exports.updateRole = async (req, res) => {
    try {
        const { roleId } = req.params;
        const { role } = req.body;

        const updatedRole = await Role.findByIdAndUpdate(
            roleId,
            { role },
            { new: true, runValidators: true } // Ensure validations are applied
        );

        if (!updatedRole) {
            return res.status(404).json({ message: 'Role not found' });
        }

        res.status(200).json({
            message: 'Role updated successfully',
            role: updatedRole,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
};

// Delete a role by its ID
exports.deleteRole = async (req, res) => {
    try {
        const { roleId } = req.params;
        const deletedRole = await Role.findByIdAndDelete(roleId);

        if (!deletedRole) {
            return res.status(404).json({ message: 'Role not found' });
        }

        res.status(200).json({
            message: 'Role deleted successfully',
            role: deletedRole,
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error' });
    }
};
