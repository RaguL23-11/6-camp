const express = require('express');

//create a router object to handle routes or path
const router = express.Router();
//import  placecontroller
const employeeControllers = require('../controllers/employee-controller');
const HttpError = require('../model/http-errors');

const {check}=require('express-validator');


// Express-validator for creating an employee
router.post('/', [
    check('fullname').isLength({ min: 3 }),
    check('email').isEmail(), 
    check('position').notEmpty(),
    
    check('dateOfBirth').isDate(),
    check('dateOfJoining').isDate(),
    check('salary').isNumeric()
], employeeControllers.createEmployee);
router.get('/',employeeControllers.getallEmployee);
router.get('/:eid',employeeControllers.getEmployeeById);
router.patch('/:eid',employeeControllers.updateEmployee);
router.delete('/:eid',employeeControllers.deleteEmployee);


module.exports =router;


module.exports = router