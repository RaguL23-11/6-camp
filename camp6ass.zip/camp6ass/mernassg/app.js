//stating point of our application
const express = require('express');
const bodyParser = require('body-parser');
const app = express();

const employeesroutes = require('./routes/employee-routes');
const departmentsroutes = require('./routes/department-routes')



//to fetch  the data from the body 
const mongoose=require('mongoose')

app.use(bodyParser.json());
app.use('/api/employees/departments',departmentsroutes);
app.use('/api/employees',employeesroutes);




//middleware to handle unimplemented routes or path
app.use((req,res,next)=>{
    const error=new HttpError('could not find this route',404);
    throw error;
  });


  app.use((err, req, res, next) => {
    //if the response is sent it will pass to another middleware
   if(res.headerSent){
    return next(err)
   }
    res.status(err.code || 500);
    res.json({message:err.message} || 'An unknown error occured!');
  })

  mongoose.connect('mongodb+srv://ragul:ragul123@cluster.y2mqu.mongodb.net/employees?retryWrites=true&w=majority&appName=Cluster')
.then(()=>{
  //to start the server 
app.listen(5000);

}).catch(err=>{
  console.log(err);
})


