const mongoose = require('mongoose');

const Schema = mongoose.Schema;

//creating schema and from schema we will create model
const EmployeeSchema = new Schema({
    fullname: { type: String, required: true },
    email: { type: String, required: true },
    position: { type: String, required: true },
    dateOfBirth: { type: Date, required: true },
    dateOfJoining: { type: Date, required: true },
    salary: { type: Number, required: true },
    department: { type: mongoose.Types.ObjectId, required: true, ref: 'Department' }
});








module.exports=mongoose.model('Employee',EmployeeSchema);