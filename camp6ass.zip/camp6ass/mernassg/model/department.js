
const mongoose=require('mongoose');
const Schema=mongoose.Schema;
const uniqueValidator=require('mongoose-unique-validator');

const DepartmentSchema = new Schema({
    name : {type: String, required:true,unique:true},
    employees:[{type:mongoose.Types.ObjectId,required:true,ref:'Employee'}]  //can have many employees
    
});








DepartmentSchema.plugin(uniqueValidator);
module.exports=mongoose.model('Department',DepartmentSchema);
